import paho.mqtt.client as mqtt
import time
import json
from datetime import datetime

# Define the broker and topic
broker = "test.mosquitto.org"  # Example broker
topic = "datalogar/batch001"  # Replace with your topic

# Create an MQTT client instance
client = mqtt.Client()

# Connect to the MQTT broker
client.connect(broker, 1883, 60)

data ={"parameters": [{ "parameter_key": "ph", "parameter_value":' '}]} 
#data= {"parameters": [{"parameter_key": "cod","parameter_value": 100},{"parameter_key": "bod","parameter_value": 200},{"parameter_key": "tss","parameter_value": ''}]}
#data = json.loads(data)
#apilink= "https://vaksys.com/sagar_api/api/device_data/SLBQD7CA/SLBQLR7D/SLBQNK3F"
apilink = "https://vaksys.com/sagar_api/api/device_data/SLBQD7CA/SLBQM0F2/SLBQN00D"
apikey = "4xCOWlaAAGwa8uBEwIhMfcKnqSrxFPiz"

# Start the loop to ensure that the client can process network traffic 'E6612483CB5C4C24'
client.loop_start()

for i in range(0, 5):
    # Create the message
    message = {
        "ID": 'E6612483CB5C4C26',
        "API": apilink,
        "key": apikey,
        "Json_Data": data,
        "Time": datetime.now().isoformat()
    }

    # Convert the message to a JSON string
    json_payload = json.dumps(message)

    # Publish the JSON payload
    client.publish(topic, json_payload)
    print(f"Published JSON data: {json_payload}")

    # Wait for 10 seconds before the next message
    time.sleep(10)

# Stop the loop and disconnect from the broker
client.loop_stop()
client.disconnect()

