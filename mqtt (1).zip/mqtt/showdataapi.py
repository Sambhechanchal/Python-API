import requests

# Replace with your API endpoint
url = 'http://127.0.0.1:5001/api/getinfo'

# Optional: add headers if required by the API
headers = {
    'Authorization': '91b4852fc256a6102dd64f1ef8b12786',  # if authentication is needed
    'Content-Type': 'application/json'  # adjust as necessary
}

try:
    response = requests.get(url, headers=headers)
    response.raise_for_status()  # Raise an error for bad responses

    # Process the response data (usually JSON)
    data = response.json()
    print(data)

except requests.exceptions.HTTPError as err:
    print(f'HTTP error occurred: {err}')
except Exception as err:
    print(f'Other error occurred: {err}')

