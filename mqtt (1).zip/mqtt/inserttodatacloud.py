'''import pymysql 
from datetime import date
from datetime import datetime
maxRecord = 2000
# calling the today
# function of date class
#today = date.today()
#date_time = datetime.now()
#time = date_time.strftime("%H:%M:%S")

# Getting Datetime from timestamp
INOBJECT=0
OUTOBJECT=0
TOTALOBJECT=0
#DATE=today
#TIME=time	
time = datetime.now()
Host = "localhost"  
# User name of the database server 
User = "root"       
# Password for the database user 
Password = "root"            
  
database = "DATALOGGER"
# this function will insert the data if this is new entry to database

def InsertNewData(ID=0,API=0,apikey=0,Json_Data=0):
	conn  = pymysql.connect(host=Host, user=User, password=Password, database=database) 
    # Create a cursor object 
	cursor  = conn.cursor() 
	query = "INSERT INTO data(ID,API,APIKEY,Json_Data,Time)VALUES({ID},{API},{apikey},{Json_Data},{time})"
	cursor.execute(query)
	conn.commit() 
	#conn.close()
	print(f"{cursor.rowcount} details inserted") 
if __name__ == "__main__": 
	val1 = input("enter ID:-- ")	
	val2 = input("enter APIlink:-- ") 
	val3 = input("enter APIKEY:-- ")
	InsertNewData(val1,val2,val3)'''
	
import pymysql
from datetime import datetime

# Database connection details
Host = "localhost"  
User = "root"       
Password = "root"            
database = "DATALOGGER"

# Function to insert new data into the database
def InsertNewData(ID=0, API=0, apikey=0, Json_Data=0):
    conn = pymysql.connect(host=Host, user=User, password=Password, database=database)
    
    try:
        # Create a cursor object 
        cursor = conn.cursor()
        
        # Check if the ID already exists
        cursor.execute("SELECT COUNT(*) FROM data WHERE ID = %s", (ID,))
        exists = cursor.fetchone()[0]
        
        if exists == 0:
            # Use parameterized query to prevent SQL injection
            query = "INSERT INTO data (ID, API, APIKEY, Json_Data, Time) VALUES (%s, %s, %s, %s, %s)"
            
            # Get the current time
            time = datetime.now().isoformat()
            
            # Execute the query with parameters
            cursor.execute(query, (ID, API, apikey, Json_Data, time))
            
            # Commit the changes
            conn.commit()
            
            return f"{cursor.rowcount} details inserted" 
        else:
            return f"Record with ID {ID} already exists."
            
    except Exception as e:
        return f"An error occurred: {e}"
    finally:
        # Close the connection
        conn.close()

if __name__ == "__main__": 
    '''val1 = input("Enter ID: ")    
    val2 = input("Enter API link: ") 
    val3 = input("Enter API key: ")
    json_data = input("Enter JSON data: ")  # Add input for JSON data
    InsertNewData(val1, val2, val3, json_data)'''


