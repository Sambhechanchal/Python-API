import hashlib

# encoding GeeksforGeeks using md5 hash
# function 
result = hashlib.md5(b'1234abcdPBR')

# printing the equivalent byte value.
#print("The byte equivalent of hash is : ", end =&quot;&quot;)
print(result.hexdigest())
