import pymysql
import json
from time import sleep
from loadDatatoAPI import LoadData

# Database connection details
HOST = "localhost"
USER = "root"
PASSWORD = "root"
DATABASE = "DATALOGGER"

# Function to fetch and update data in the database
def fetch_data():
    while True:
        conn = None
        try:
            # Connect to the database
            conn = pymysql.connect(host=HOST, user=USER, password=PASSWORD, database=DATABASE)
            cursor = conn.cursor()

            # Query to fetch all records
            query = "SELECT * FROM data"
            cursor.execute(query)
            records = cursor.fetchall()

            if records:
                firstID = records[0][5]
                lastID = records[-1][5] + 1  # Increment lastID for the loop

                for i in range(firstID, lastID):
                    # Query to fetch API details
                    update_query = "SELECT API, APIKEY, ID, Json_Data FROM data WHERE idkey = %s"
                    cursor.execute(update_query, (i,))
                    api_record = cursor.fetchone()  # Fetch single record

                    if api_record:
                        API, apikey, ID, json_data = api_record

                        # Ensure json_data is a proper JSON string
                        if isinstance(json_data, str):
                            json_payload = json_data
                        else:
                            json_payload = json.dumps(json_data)

                        # Debugging: Print the ID being processed
                        print("Processing ID:", ID)

                        # Send the data to the API
                        response = LoadData(API, apikey, json_payload)
                        if response['status'] is False:
                            print("API Error:", response['message'])

                conn.commit()  # Commit changes if needed
                sleep(10)  # Wait after processing all records

            else:
                print("No records found.")

        except Exception as e:
            print(f"An error occurred: {e}")

        finally:
            # Close the connection if it was opened
            if conn:
                conn.close()

        # Sleep for 30 seconds before the next iteration
        sleep(30)

if __name__ == "__main__":
    fetch_data()

