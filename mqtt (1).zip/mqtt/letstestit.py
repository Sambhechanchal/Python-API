import pymysql
import json  # Make sure to import the json module
from time import sleep
from loadDatatoAPI import LoadData

def NewData( val2, val3, json_data):
	#json_data = json.dumps(json_data) 
	LoadData( val2, val3, json_data)


if __name__ == "__main__": 
    #val1 = input("Enter ID: ")	
	val2 = input("Enter API link: ") 
	val3 = input("Enter API key: ")
	json_data = input("Enter JSON data: ") 
	#json_data = json.dumps(json_data) # Correctly capture JSON data
	NewData( val2, val3, json_data)
