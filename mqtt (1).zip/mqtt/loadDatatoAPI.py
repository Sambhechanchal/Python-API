import subprocess
import json

def LoadData(api, apikey, json_data):
    # Prepare the curl command template
    #json_data = json.dumps(json_data)
    curl_command_template = [
        "curl",
        "-X", "POST",  # Specify the HTTP method
        api,  # API URL
        "-H", "Content-Type: application/json",  # Content-Type header
        "-H", f"X-API-KEY: {apikey}",  # API Key header
        "-H", "Cookie: csrf_pms=121893945a4aad4285119786ca59cf90; pms_session=ccada0e7385b6614a8a5dc548bfa98d20442f8d8",
        "-d" ,json_data,
    ]

    # Convert json_data to a JSON string
    #json_payload = json.dumps(json_data)

    # Update the curl command to include the JSON data
    curl_command = curl_command_template #+ ["-d", json_data]

    try:
        # Execute the curl command
        response = subprocess.run(curl_command, capture_output=True, text=True)

        # Check the response
        if response.returncode == 0:
            print("Response Code: 200 (Okay)")
            print("Response Text:", response.stdout)
            return {'status': True, 'message': response.stdout}
        else:
            print(f"Error: {response.returncode}")
            print("Response Text:", response.stderr)  # Use stderr for errors
            return {'status': False, 'message': response.stderr}

    except Exception as e:
        print("An error occurred:", e)
        return {'status': False, 'message': str(e)}

if __name__ == "__main__": 
    val2 = input("Enter API link: ") 
    val3 = input("Enter API key: ")
    
    # Prompt for JSON data
    print("Enter JSON data:")
    json_data_input = input()  # Get input for JSON data

    try:
        json_data = json.loads(json_data_input)  # Convert input string to JSON
        response = LoadData(val2, val3, json_data)
        print("LoadData response:", response)
    except json.JSONDecodeError as e:
        print("Invalid JSON format. Please ensure your input is valid JSON.")
        print("Error details:", e)


   
        #https://vaksys.com/sagar_api/api/device_data/SLBQD7CA/SLG5L649/SLG5J25C,4xCOWlaAAGwa8uBEwIhMfcKnqSrxFPiz,{"parameters":[{"parameter_name":"PM 2.5","parameter_value":100},{"parameter_name":"PM10","parameter_value":200}]} {"parameters": [{"parameter_name": "BOD","parameter_value": 1300},{"parameter_name": "COD","parameter_value": 250},{"parameter_name": "TSS","parameter_value": 1000}]}

