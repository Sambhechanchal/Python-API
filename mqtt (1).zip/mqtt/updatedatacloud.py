import pymysql
from datetime import datetime, timedelta

# Database connection details
Host = "localhost"  
User = "root"       
Password = "root"            
database = "DATALOGGER"

# Function to update data in the database
def UpdateNewData(ID, APIlink, apikey, Json_Data):
    try:
        with pymysql.connect(host=Host, user=User, password=Password, database=database) as conn:
            # Create a cursor object 
            cursor = conn.cursor()
            cursor.execute("SELECT Time FROM data WHERE ID = %s AND API = %s AND APIKEY = %s", (ID, APIlink, apikey))
            result = cursor.fetchone()

            if result is None:
                return "No record found for the provided ID, API link, and API key."

            last_update_time = datetime.fromisoformat(result[0])
            current_time = datetime.now()
            time_difference = current_time - last_update_time

            #if time_difference > timedelta(seconds=60):
                #return "Update can only happen before 1 minute."

            # Prepare the update query
            update_query = "UPDATE data SET Json_Data = %s, Time = %s WHERE ID = %s AND API = %s AND APIKEY = %s"
            time_now = datetime.now().isoformat()

            # Execute the update query
            cursor.execute(update_query, (Json_Data, time_now, ID, APIlink, apikey))
            conn.commit()

            return f"{cursor.rowcount} details updated"
    except Exception as e:
        return f"An error occurred: {e}"

if __name__ == "__main__": 
    '''# Uncomment and use these lines as needed for testing
    # val1 = input("Enter ID: ")	
    # val2 = input("Enter API link: ") 
    # val3 = input("Enter API key: ")
    # json_data = input("Enter JSON data: ")  # Correctly capture JSON data
    # print(UpdateNewData(val1, val2, val3, json_data))'''

