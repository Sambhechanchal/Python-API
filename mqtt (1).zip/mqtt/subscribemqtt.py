import paho.mqtt.client as mqtt
import json
from updatedatacloud import UpdateNewData

def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
    client.subscribe("datalogar/batch001")

def on_message(client, userdata, msg):
    payload = msg.payload.decode()
    
    try:
        # Convert JSON string back to Python dictionary
        data = json.loads(payload)
        
        # Access and print received data
        print(f"Received message: ID={data['ID']}")
        print(f"Received message: API={data['API']}")
        print(f"Received message: APIKEY={data['key']}")

        # Extract relevant data
        ID = data['ID']
        APIlink = data['API']
        apikey = data['key']
        
        # Check if 'Json_Data' exists and is a dictionaryJson_Data = 
        if 'Json_Data' in data and isinstance(data['Json_Data'], dict):
            Json_Data = data['Json_Data']
            
            # Check if 'parameters' exists and is a non-empty list
            if 'parameters' in Json_Data and isinstance(Json_Data['parameters'], list) and Json_Data['parameters']:
                # Iterate over parameters to check values
                for param in Json_Data['parameters']:
                    if 'parameter_value' in param:
                        # Set to zero if parameter_value is None, empty string, or whitespace
                        if param['parameter_value'] is None or (isinstance(param['parameter_value'], str) and param['parameter_value'].strip() == ''):
                            param['parameter_value'] = 0  # Set to zero if empty

                Json_Data = json.dumps(Json_Data)  # Convert to JSON string
            else:
                Json_Data = None  # Set to None if conditions are not met
        else:
            Json_Data = None  # If 'Json_Data' key is missing or not a dict

        # Call the UpdateNewData function
        result = UpdateNewData(ID, APIlink, apikey, Json_Data)
        print(result)
    
    except json.JSONDecodeError:
        print("Failed to decode JSON message.")
    except KeyError as e:
        print(f"Missing key in data: {e}")

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.enable_logger()  # Enable logging
client.connect("test.mosquitto.org", 1883, 60)
client.loop_forever()



'''import paho.mqtt.client as mqtt
import json
from updatedatacloud import UpdateNewData

def on_connect(client, userdata, flags, rc):
	print(f"Connected with result code {rc}")
	client.subscribe("datalogar/batch001")

def on_message(client, userdata, msg):
	payload = msg.payload.decode()
	    
	try:
        # Convert JSON string back to Python dictionary
		data = json.loads(payload)
			
			# Access and print received data
		print(f"Received message: ID={data['ID']}")
		print(f"Received message: API={data['API']}")
		print(f"Received message: APIKEY={data['key']}")
		print(f"Received message: APIKEY={data['Json_Data']}")
			# Extract relevant data
		ID = data['ID']
		APIlink = data['API']
		apikey = data['key']
		Json_Data= data['Json_Data']
        # Check if 'parameters' exists and is a non-empty list
		if 'parameters' in Json_Data and isinstance(Json_Data['parameters'], list) and Json_Data['parameters']:
            # Iterate over parameters to check values
			for param in Json_Data['parameters']:
				if 'parameter_value' in param and (param['parameter_value'] is None or param['parameter_value'] == ''):
					param['parameter_value'] = '0 ' # Set to zero if empty

					Json_Data = json.dumps(Json_Data['parameters'])  # Convert to JSON string
		else:
			Json_Data = json.dumps(Json_Data)  # Set to None if conditions are not met

        # Call the UpdateNewData function
		result = UpdateNewData(ID, APIlink, apikey, Json_Data)
		print(result)
    
	except json.JSONDecodeError:
		print("Failed to decode JSON message.")
	except KeyError as e:
		print(f"Missing key in data: {e}")

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.enable_logger()  # Enable logging
client.connect("test.mosquitto.org", 1883, 60)
client.loop_forever()'''

