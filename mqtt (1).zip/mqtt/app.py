'''from flask import Flask, jsonify

app = Flask(__name__)
books = [{'id': 1, 'title': 'Python Essentials', 'author': 'Jane Doe'}]

@app.route('/books', methods=['GET'])
def get_books():
    return jsonify({'books': books})

if __name__ == '__main__':
	#app.run(port=5001)
	app.run(debug=True)'''
	
	
'''from flask import Flask,jsonify
app = Flask(__name__) 
from inserttodatacloud import InsertNewData
@app.route('/api.getinfo.com')
def home():
	a = input("enter api ID:-- ")
	b = input("enter api link:-- ")
	c = input("enter api API KEY:-- ")
	InsertNewData(a, b, c,Json_Data="null")
	return jsonify(message=(a,b,c))

if __name__ == '__main__':
	app.run(debug=True,port=5001)'''

'''from flask import Flask, request, jsonify

app = Flask(__name__)
received_data=[]
@app.route('/receive_data', methods=['POST'])
def receive_data():
    data = request.json  # Get the JSON data from the request
    received_data.append(data)
    print("Received data:" ,data)
    return jsonify({"received": data}), 201  # Respond with the received data
@app.route('/view_data')
def view_data():
	return jsonify(received_data)

if __name__ == '__main__':
    app.run(port=5000)'''
    
from flask import send_from_directory
from flask import Flask, jsonify, request
from inserttodatacloud import InsertNewData
import hashlib

app = Flask(__name__)

@app.route('/api/getinfo', methods=['POST'])
def get_info():
    
	key= request.headers.get('X-API-KEY')
	if key != '91b4852fc256a6102dd64f1ef8b12786':
		return jsonify({"error":"Unauthorized"}),401
# Get JSON data from the request
	data = request.get_json()
    # Validate that data is provided
	if not data or not all(k in data for k in ("api_id", "api_link", "api_key")):
		return jsonify({"error": "Missing data"}), 400

    # Extract values from the incoming JSON data
	a = data['api_id']
	b = data['api_link']
	c = data['api_key']

    # Call your function
	response = InsertNewData(a, b, c, Json_Data=None)  # Use None instead of "null"
	return {'message': (response, a, b, c)}
	#return jsonify(message=(a, b, c)), 200

def run_cli():
	a = input("Enter API ID: ")
	b = input("Enter API link: ")
	c = input("Enter API KEY: ")
	    
	    # Simulate calling the function directly
	InsertNewData(a, b, c, Json_Data=None)
	print("Data inserted:", a, b, c)
#@app.route('/favicon.ico')
#def favicon():
    #return send_from_directory('static', 'favicon.ico', mimetype='image/vnd.microsoft.icon')
if __name__ == '__main__':
    # Uncomment the line below if you want to run CLI input
    # run_cli()
    
    app.run(debug=True,port=5001)
    
'''from flask import Flask, jsonify, request
from inserttodatacloud import InsertNewData

app = Flask(__name__)

@app.route('/api/getinfo', methods=['POST'])
def home():
    # Get JSON data from the request
    data = request.get_json()
    
    # Validate that data is provided
    if not data or not all(k in data for k in ("api_id", "api_link", "api_key")):
        return jsonify({"error": "Missing data"}), 400
    
    # Extract values from the incoming JSON data
    a = data['api_id']
    b = data['api_link']
    c = data['api_key']
    
    # Call your function
    InsertNewData(a, b, c, Json_Data=None)  # Use None instead of "null" for Python
    return jsonify(message=(a, b, c)), 200

if __name__ == '__main__':
    app.run(debug=True, port=5001)'''


